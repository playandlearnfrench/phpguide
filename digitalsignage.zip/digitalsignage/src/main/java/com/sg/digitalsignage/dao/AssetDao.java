package com.sg.digitalsignage.dao;

import java.util.List;
import com.sg.digitalsignage.model.Asset;

public interface AssetDao {
	List<Asset> getAllAssets();
}
