package com.sg.digitalsignage.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class mytableDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	 
	 public List<MyTable> listAllValues(){
	  List<MyTable> mytble = new ArrayList<MyTable>();
	  try
	   {
	    
	    String selectSQL="select * from mytable ;";
	    
	    List<MyTable> rows =  jdbcTemplate.query(selectSQL,new ResultSetRowMapper());
	    Iterator<MyTable> itrList=rows.iterator();
	     
	    while(itrList.hasNext()){
	     MyTable mytab=itrList.next();
	     
	     System.out.println(" "+mytab.getId()+"\t "+ mytab.getName()+"\t "+mytab.getMobile());
	      mytble.add(mytab);
	    }	   
	   } catch (Exception e) {
	    e.printStackTrace();
	   }
	  return mytble;
	 }
}
