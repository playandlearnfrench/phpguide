package com.sg.digitalsignage.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sg.digitalsignage.model.Asset;

public class AssetSetRowMapper implements RowMapper<Object> {
	
	public Object mapRow(ResultSet rs, int rownum) throws SQLException {
		Asset asset = new Asset();
		asset.setAsset_id(rs.getString("asset_id"));
		asset.setName(rs.getString("name"));
		asset.setUri(rs.getString("uri"));
		asset.setMd5(rs.getString("md5"));
		asset.setDuration(rs.getString("duration"));
		asset.setMimetype(rs.getString("mimetype"));
		asset.setStart_date(rs.getTimestamp("start_date"));
		asset.setEnd_date(rs.getTimestamp("end_date"));
//		asset.setStart_date(rs.getString("start_date"));
//		asset.setEnd_date(rs.getString("end_date"));
		asset.setIs_enabled(rs.getInt("is_enabled"));
		asset.setNocache(rs.getInt("Nocache"));
		asset.setPlay_order(rs.getInt("play_order"));
		return asset;
	}
}
