package com.sg.digitalsignage.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.springframework.jdbc.core.RowMapper;

import com.sg.digitalsignage.model.Asset;

public class AssetSetRowMapper implements RowMapper<Object> {
	
	public Object mapRow(ResultSet rs, int rownum) throws SQLException {
		Asset asset = new Asset();
		asset.setAsset_id(rs.getString("asset_id"));
		asset.setName(rs.getString("name"));
		asset.setUri(rs.getString("uri"));
		asset.setMd5(rs.getString("md5"));
		asset.setDuration(rs.getString("duration"));
		asset.setMimetype(rs.getString("mimetype"));
		//asset.setStart_date(rs.getTimestamp("start_date"));
		//asset.setEnd_date(rs.getTimestamp("end_date"));
		asset.setStart_date(convertDateFormat(rs.getString("start_date")));
		asset.setEnd_date(convertDateFormat(rs.getString("end_date")));
		asset.setIs_enabled(rs.getInt("is_enabled"));
		asset.setNocache(rs.getInt("Nocache"));
		asset.setPlay_order(rs.getInt("play_order"));
		asset.setIs_active(false);
		
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
		Date date = null;
		Date dateNow = new Date(System.currentTimeMillis());
		try {
			date = format.parse(rs.getString("end_date"));			
			if(date.compareTo(dateNow)>0){
				asset.setIs_active(true);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}		
		return asset;
	}
	private String convertDateFormat(String inputDate){
		String outputDate=inputDate;
		DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		try {
			Date convertedDate = inputFormat.parse(inputDate);
			outputDate=outputFormat.format(convertedDate.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return outputDate;
	}
}
