package com.sg.digitalsignage.dao;

public class MyTable {
	int id;
	 String name;
	 String mobile;
	/**
	 * @return the id
	 */
	public int getId() {
	 return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
	 this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
	 return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
	 this.name = name;
	}
	/**
	 * @return the mobile
	 */
	public String getMobile() {
	 return mobile;
	}
	/**
	 * @param mobile the mobile to set
	 */
	public void setMobile(String mobile) {
	 this.mobile = mobile;
	}
}
