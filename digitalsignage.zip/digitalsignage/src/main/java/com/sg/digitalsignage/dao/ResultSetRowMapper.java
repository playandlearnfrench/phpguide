package com.sg.digitalsignage.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ResultSetRowMapper implements RowMapper {

	 public Object mapRow(ResultSet rs, int rownum) throws SQLException {
	  
	  MyTable mytable=new MyTable();
	  
	  mytable.setId(rs.getInt(1));
	  mytable.setName(rs.getString(2));
	  mytable.setMobile(rs.getString(3));
	  
	  return mytable;
	 }

	}