package com.sg.digitalsignage.service;

import java.util.List;

import com.sg.digitalsignage.model.Asset;

public interface AssetService {
	List<Asset> getAssets();
	Asset findById(String assetId);
	Integer updateAsset(Asset asset);
	Integer addAsset(Asset asset);
}
