package com.sg.digitalsignage.service;

import java.util.List;

import com.sg.digitalsignage.model.Asset;

public interface AssetService {
	public List<Asset> getAssets();
}
