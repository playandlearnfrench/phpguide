package com.sg.digitalsignage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sg.digitalsignage.dao.AssetDao;
import com.sg.digitalsignage.model.Asset;

@Service("assetService")
public class AssetServiceImpl implements AssetService {
	
	@Autowired
	AssetDao assetDao;
	
	public List<Asset> getAssets() {
		List<Asset> assets = assetDao.getAllAssets();
		return assets;
	}

}
