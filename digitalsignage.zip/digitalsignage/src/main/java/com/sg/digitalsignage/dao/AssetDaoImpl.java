package com.sg.digitalsignage.dao;

import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sg.digitalsignage.model.Asset;

@Repository
@Transactional(readOnly = true)
public class AssetDaoImpl implements AssetDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
//	public void setSessionFactory(JdbcTemplate sessionFactory) {
//		this.jdbcTemplate = sessionFactory;
//	}
//
//	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//		this.jdbcTemplate = jdbcTemplate;
//	}
	public List<Asset> getAllAssets() {
		List<Asset> assets = new ArrayList<Asset>();
		try
		   {
		// TODO Auto-generated method stub
			String selectSQL="select * from assets;";
			
			List<Object> rows =  jdbcTemplate.query(selectSQL,new AssetSetRowMapper());
			Iterator<Object> itrList=rows.iterator();
			//List<Asset> rows  = jdbcTemplate.query(selectSQL,new BeanPropertyRowMapper(Asset.class));
			//Iterator<Asset> itrList=rows.iterator();
			
			while(itrList.hasNext()){
				 Asset asset=(Asset) itrList.next();
			     
			     System.out.println(" "+asset.getAsset_id()+"\t "+ asset.getName()+"\t "+asset.getStart_date());
			     assets.add(asset);
		    }
		  } catch (Exception e){
			  	e.printStackTrace();
		   }
		return assets;
	}

	@Override
	public Asset findByAssetId(String assetId) {
		String sql="select * from assets where asset_id=?";
		Object[] parameters = new Object[] {assetId};
		Asset asset = (Asset) jdbcTemplate.queryForObject(sql, parameters, new AssetSetRowMapper());
		return asset;
	}

	@Override
	public Integer updateAsset(Asset asset) {
		String sql="update assets set name=?, start_date=?, end_date=?, duration=?,"
				+ " play_order=?, is_enabled=? where asset_id=?";
		return jdbcTemplate.update(sql, new Object[]{asset.getName(),asset.getStart_date(),
				asset.getEnd_date(),asset.getDuration(),asset.getPlay_order(),asset.getIs_enabled(),asset.getAsset_id()});
	}

	@Override
	public Integer addAsset(Asset asset) {
		String sql="insert into assets(asset_id,name,uri,start_date,end_date,duration,mimetype) values(?,?,?,?,?,?,?) ";
		// define query arguments
		Asset finalAsset=prepareAsset(asset);
		Object[] params = new Object[] { finalAsset.getAsset_id(),finalAsset.getName(),finalAsset.getUri(),
				finalAsset.getStart_date(),finalAsset.getEnd_date(),finalAsset.getDuration(),finalAsset.getMimetype() };
		
		// define SQL types of the arguments
		int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, 
						Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
		
		return jdbcTemplate.update(sql, params, types);
	}

	private Asset prepareAsset(Asset asset) {
		Asset tempAsset=new Asset();
		tempAsset.setAsset_id(asset.getAsset_id());
		tempAsset.setDuration(asset.getDuration());
		tempAsset.setName(asset.getName());
		tempAsset.setMimetype(asset.getMimetype());
		tempAsset.setUri(asset.getUri());
		tempAsset.setStart_date(convertDateFormat(asset.getStart_date()));
		tempAsset.setEnd_date(convertDateFormat(asset.getEnd_date()));
		return tempAsset;
	}
	
	private String convertDateFormat(String inputDate){
		String outputDate=inputDate;
		if(inputDate.contains(".")){
			String[] tempDate = inputDate.split("\\.");
			outputDate=tempDate[0];
		}		
		DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			Date convertedDate = inputFormat.parse(inputDate);
			outputDate=outputFormat.format(convertedDate.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return outputDate;
	}

}
