package com.sg.digitalsignage.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sg.digitalsignage.model.Asset;

@Repository
@Transactional(readOnly = true)
public class AssetDaoImpl implements AssetDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
//	public void setSessionFactory(JdbcTemplate sessionFactory) {
//		this.jdbcTemplate = sessionFactory;
//	}
//
//	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//		this.jdbcTemplate = jdbcTemplate;
//	}
	public List<Asset> getAllAssets() {
		List<Asset> assets = new ArrayList<Asset>();
		try
		   {
		// TODO Auto-generated method stub
			String selectSQL="select * from assets;";
			
			List<Object> rows =  jdbcTemplate.query(selectSQL,new AssetSetRowMapper());
			Iterator<Object> itrList=rows.iterator();
			//List<Asset> rows  = jdbcTemplate.query(selectSQL,new BeanPropertyRowMapper(Asset.class));
			//Iterator<Asset> itrList=rows.iterator();
			
			while(itrList.hasNext()){
				 Asset asset=(Asset) itrList.next();
			     
			     System.out.println(" "+asset.getAsset_id()+"\t "+ asset.getName()+"\t "+asset.getStart_date());
			     assets.add(asset);
		    }
		  } catch (Exception e){
			  	e.printStackTrace();
		   }
		return assets;
	}

}
