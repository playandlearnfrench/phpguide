package com.sg.digitalsignage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.jboss.logging.Logger;
import org.springframework.web.servlet.ModelAndView;

import com.sg.digitalsignage.dao.mytableDao;
import com.sg.digitalsignage.service.AssetService;

@Controller
public class AssetMasterController {
	
	@Autowired
	AssetService assetService;
	
	//private static final Logger logger = Logger.getLogger(AssetMasterController.class);
	@RequestMapping(value="/home")
    public ModelAndView home() {
        ModelAndView model = new ModelAndView("home");
        model.addObject("name", "Oinam Singh");
        assetService.getAssets();
        return model;
    }
	
//	@Autowired
//	private mytableDao edao;
//	
//	 @RequestMapping("/hello")
//	  public ModelAndView helloWorld(){
//		  String message="Welcome to MVC Sample!!!";
//		  List resultSet= edao.listAllValues();
//		  ModelAndView modelView=new ModelAndView("home","message",message);
//		  modelView.addObject("results", resultSet);
//		  return modelView;	  
//	 }
}
