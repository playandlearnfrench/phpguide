package com.sg.digitalsignage.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;  
import org.springframework.web.bind.annotation.RestController;

import com.sg.digitalsignage.model.Asset;
import com.sg.digitalsignage.model.Employee;
import com.sg.digitalsignage.service.AssetService;

@RestController
@RequestMapping("/service") 
public class AssetRestController {
	
	@Autowired
	AssetService assetService;
	
	//-------------------Retrieve All Users--------------------------------------------------------
	@RequestMapping(value = "/asset/", method = RequestMethod.GET)
	public ResponseEntity<List<Asset>>  getAssets() {
		List<Asset> assets = assetService.getAssets();
		if(assets.isEmpty()){
			return new ResponseEntity<List<Asset>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Asset>>(assets,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/{name}", method = RequestMethod.GET)  
	 public String sayHello(@PathVariable String name) {  
		String result="Hello "+name+" to digital signage";    
		return result;  
	 }	
	 
    @RequestMapping(value = "/employee/{name}", method = RequestMethod.GET, produces = "application/json")
    public Employee getEmployeeInJSON(@PathVariable String name) {
    	Employee employee = new Employee();
   	    employee.setName(name);
   	    employee.setEmail("employee1@yahoo.com");
   	    return employee;
    }
    
    @RequestMapping(value = "/getEmployee/{name}")
    public Employee employee(@PathVariable String name) {
    	Employee employee = new Employee();
   	    employee.setName(name);
   	    employee.setEmail("employee1@yahoo.com");
   	    return employee;
    }
    
    @RequestMapping(value = "/employee/{name}.xml", method = RequestMethod.GET, produces = "application/xml")
    public Employee getEmployeeInXML(@PathVariable String name) {
    	Employee employee = new Employee();
	   	employee.setName(name);
	   	employee.setEmail("employee1@yahoos.com"); 
	   	return employee;
    }
}
