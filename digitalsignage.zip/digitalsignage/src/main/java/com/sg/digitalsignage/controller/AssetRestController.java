package com.sg.digitalsignage.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;  
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sg.digitalsignage.model.Asset;
import com.sg.digitalsignage.model.Employee;
import com.sg.digitalsignage.service.AssetService;

@RestController
@RequestMapping("/") 
public class AssetRestController {
	
	@Autowired
	AssetService assetService;
	
	//-------------------Retrieve All Users--------------------------------------------------------
	@RequestMapping(value = "/assets", method = RequestMethod.GET)
	public ResponseEntity<List<Asset>>  getAssets() {
		List<Asset> assets = assetService.getAssets();
		if(assets.isEmpty()){
			return new ResponseEntity<List<Asset>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Asset>>(assets,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/assets/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Asset> updateAssets(@PathVariable("id") String assetId,@RequestBody String model) {
		String[] jsonModel = model.split("=");
		String param1AfterDecoding = null;
		ObjectMapper mapper = new ObjectMapper();
		Asset asset=null;
		try {
			param1AfterDecoding = URLDecoder.decode(jsonModel[1], "UTF-8");
			asset = mapper.readValue(param1AfterDecoding, Asset.class);
		}catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Asset currentAsset = assetService.findById(assetId);
        
        if (currentAsset==null) {
            System.out.println("Asset with id " + assetId + " not found");
            return new ResponseEntity<Asset>(HttpStatus.NOT_FOUND);
        }
 
        currentAsset.setName(asset.getName());
        currentAsset.setDuration(asset.getDuration());
        currentAsset.setIs_enabled(asset.getIs_enabled());
        currentAsset.setEnd_date(asset.getEnd_date().replace("T", " "));
        currentAsset.setStart_date(asset.getStart_date().replace("T", " "));
        
        assetService.updateAsset(currentAsset);
		return new ResponseEntity<Asset>(currentAsset, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/asset/{name}", method = RequestMethod.GET)  
	 public String sayHello(@PathVariable String name) {  
		String result="Hello "+name+" to digital signage";    
		return result;  
	 }	
	 
	//-------------------Retrieve All Users--------------------------------------------------------
		@RequestMapping(value = "/assets", method = RequestMethod.POST)
		public ResponseEntity<Asset> addAssets(MultipartHttpServletRequest request, HttpServletResponse response) {
			Asset asset=new Asset();
	    	String fileName = null;
	    	Iterator<String> itr =  request.getFileNames();	    	 
	        MultipartFile file = request.getFile(itr.next());
	        asset.setAsset_id("sdfdsfdsfdsf");
			asset.setName(request.getParameter("name"));
			asset.setMimetype(request.getParameter("mimetype"));
			asset.setDuration(request.getParameter("duration"));
			asset.setIs_enabled(0);
			asset.setStart_date(request.getParameter("start_date"));
			asset.setEnd_date(request.getParameter("end_date"));
			
	        System.out.println(file.getOriginalFilename() +" uploaded!");
	    	if (!file.isEmpty()) {
	            try {
	                fileName = file.getOriginalFilename();
	                byte[] bytes = file.getBytes();
	                BufferedOutputStream buffStream = 
	                        new BufferedOutputStream(new FileOutputStream(new File("C:/temp/" + fileName)));
	                buffStream.write(bytes);
	                buffStream.close();
	                System.out.println("You have successfully uploaded " + fileName);
	                assetService.addAsset(asset);
	                return new ResponseEntity<Asset>(asset,HttpStatus.OK);
	            } catch (Exception e) {
	                System.out.println("You failed to upload " + fileName + ": " + e.getMessage());
	                return new ResponseEntity<Asset>(HttpStatus.NO_CONTENT);
	            }
	        } else {
	        	System.out.println("Unable to upload. File is empty.");
	            return new ResponseEntity<Asset>(HttpStatus.NO_CONTENT);
	        }    	
	}
		
    @RequestMapping(value = "/employee/{name}", method = RequestMethod.GET, produces = "application/json")
    public Employee getEmployeeInJSON(@PathVariable String name) {
    	Employee employee = new Employee();
   	    employee.setName(name);
   	    employee.setEmail("employee1@yahoo.com");
   	    return employee;
    }
    
    @RequestMapping(value = "/getEmployee/{name}")
    public Employee employee(@PathVariable String name) {
    	Employee employee = new Employee();
   	    employee.setName(name);
   	    employee.setEmail("employee1@yahoo.com");
   	    return employee;
    }
    
    @RequestMapping(value = "/employee/{name}.xml", method = RequestMethod.GET, produces = "application/xml")
    public Employee getEmployeeInXML(@PathVariable String name) {
    	Employee employee = new Employee();
	   	employee.setName(name);
	   	employee.setEmail("employee1@yahoos.com"); 
	   	return employee;
    }
}
