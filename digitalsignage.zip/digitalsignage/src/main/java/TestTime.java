import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TestTime {

	public static void main(String args[]) throws ParseException {
        // for old date
        String olddate = "2016-05-10 22:46:00";
        DateFormat inputFormate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date convertedDate = inputFormate.parse(olddate);
        //System.out.println(convertedDate.getTime());

        // for new date
        Calendar currentDate1 = Calendar.getInstance();
        SimpleDateFormat outputFormate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        String currentdate = outputFormate.format(convertedDate.getTime());
        System.out.println("newdate " + currentdate+"\nseconds " + currentDate1.getTime()+"\nAnd milli seconds = "+ System.currentTimeMillis());
        
    }

}
