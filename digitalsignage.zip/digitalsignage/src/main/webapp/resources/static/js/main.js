jQuery(function() {
  Screenly.app = new Screenly.App({
    el: $('body')
  });
});
